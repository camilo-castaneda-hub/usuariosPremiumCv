# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('Informes', '0009_auto_20160311_2210'),
    ]

    operations = [
        migrations.CreateModel(
            name='Equipo',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('Nombre', models.CharField(max_length=50, verbose_name='Nombre integrante equipo')),
                ('Cargo', models.CharField(max_length=50, verbose_name='Cargo')),
                ('Contenido', models.TextField(max_length=500, verbose_name='Informaci\xf3n del cargo')),
            ],
            options={
                'verbose_name_plural': 'Equipo Congreso Visible',
            },
        ),
    ]
