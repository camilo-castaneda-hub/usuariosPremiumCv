# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('Informes', '0008_auto_20160229_1847'),
    ]

    operations = [
        migrations.AlterModelOptions(
            name='informemensual',
            options={'verbose_name_plural': 'Informe Mensual'},
        ),
        migrations.AlterModelOptions(
            name='informesemanal',
            options={'verbose_name_plural': 'Informe Semanal'},
        ),
    ]
