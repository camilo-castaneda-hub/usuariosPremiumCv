# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations
import ckeditor.fields


class Migration(migrations.Migration):

    dependencies = [
        ('Informes', '0002_informes'),
    ]

    operations = [
        migrations.CreateModel(
            name='InformeMensual',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('titulo', models.CharField(max_length=100, verbose_name='T\xedtulo del Informe Mensual')),
                ('contenido', ckeditor.fields.RichTextField(verbose_name='Contenido del Informe')),
                ('fecha_publicacion', models.DateTimeField(verbose_name='Fecha de publicaci\xf3n')),
                ('url', models.URLField()),
                ('usuarios_premium', models.BooleanField(default=True)),
                ('usuarios_general', models.BooleanField(default=False)),
                ('comentarios', models.CharField(max_length=300, verbose_name='Comentarios del informe')),
            ],
        ),
        migrations.CreateModel(
            name='InformeNoticias',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('titulo', models.CharField(max_length=100, verbose_name='T\xedtulo del Informe')),
                ('contenido', ckeditor.fields.RichTextField(verbose_name='Contenido del Informe')),
                ('fecha_publicacion', models.DateTimeField(verbose_name='Fecha de publicaci\xf3n')),
                ('usuarios_premium', models.BooleanField(default=True)),
                ('usuarios_general', models.BooleanField(default=False)),
                ('comentarios', models.CharField(max_length=300, verbose_name='Comentarios del informe')),
            ],
        ),
        migrations.CreateModel(
            name='InformeSemanal',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('titulo', models.CharField(max_length=100, verbose_name='T\xedtulo del Informe Semanal')),
                ('contenido', ckeditor.fields.RichTextField(verbose_name='Contenido del Informe')),
                ('fecha_publicacion', models.DateTimeField(verbose_name='Fecha de publicaci\xf3n')),
                ('url', models.URLField()),
                ('usuarios_premium', models.BooleanField(default=True)),
                ('usuarios_general', models.BooleanField(default=False)),
                ('comentarios', models.CharField(max_length=300, verbose_name='Comentarios del informe')),
            ],
        ),
        migrations.DeleteModel(
            name='Informes',
        ),
    ]
