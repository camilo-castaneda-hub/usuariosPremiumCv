# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('Informes', '0011_equipo_correo'),
    ]

    operations = [
        migrations.AddField(
            model_name='equipo',
            name='ImgPerfil',
            field=models.ImageField(default='images/profileCv/generic.png', upload_to='images/profileCv'),
        ),
    ]
