# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
    ]

    operations = [
        migrations.CreateModel(
            name='ActividadActividad',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('fecha_hora', models.DateTimeField()),
                ('objeto_disparador_id', models.IntegerField(null=True, blank=True)),
                ('objeto_seguido_id', models.IntegerField(null=True, blank=True)),
                ('objeto_seguido_content_type_id', models.IntegerField(null=True, blank=True)),
                ('objeto_disparador_content_type_id', models.IntegerField(null=True, blank=True)),
            ],
            options={
                'db_table': 'actividad_actividad',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='ActividadSiguea',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('seguido_id', models.IntegerField()),
                ('fecha', models.DateTimeField(null=True, blank=True)),
            ],
            options={
                'db_table': 'actividad_siguea',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='ActividadTipoactividad',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('nombre', models.CharField(unique=True, max_length=100)),
            ],
            options={
                'db_table': 'actividad_tipoactividad',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='AyudaAyudaseccion',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('orden', models.IntegerField()),
                ('fecha_actualizacion', models.DateField()),
                ('id_video_ayuda', models.CharField(max_length=70)),
                ('regex_seccion', models.CharField(unique=True, max_length=70)),
                ('exacto', models.BooleanField()),
            ],
            options={
                'db_table': 'ayuda_ayudaseccion',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='AyudaEnlaceinteres',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('titulo', models.CharField(max_length=150)),
                ('enlace', models.CharField(max_length=200)),
                ('descripcion', models.CharField(max_length=240, null=True, blank=True)),
                ('orden', models.IntegerField(null=True, blank=True)),
            ],
            options={
                'db_table': 'ayuda_enlaceinteres',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='AyudaEnlacesseccion',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('orden', models.IntegerField()),
                ('regex_seccion', models.CharField(unique=True, max_length=70)),
            ],
            options={
                'db_table': 'ayuda_enlacesseccion',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='AyudaPreguntarespuesta',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('orden', models.IntegerField()),
                ('pregunta', models.TextField()),
                ('respuesta', models.TextField()),
            ],
            options={
                'db_table': 'ayuda_preguntarespuesta',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='BlogBlog',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('titulo', models.CharField(max_length=200)),
                ('descripcion', models.TextField(null=True, blank=True)),
                ('destacado', models.BooleanField()),
            ],
            options={
                'db_table': 'blog_blog',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='BlogBoletin',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('orden', models.IntegerField()),
                ('nombre', models.CharField(max_length=50)),
                ('anio', models.IntegerField()),
                ('objeto', models.TextField()),
                ('destacar', models.BooleanField()),
                ('archivo', models.CharField(max_length=100, null=True, blank=True)),
            ],
            options={
                'db_table': 'blog_boletin',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='BlogPost',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('created_at', models.DateTimeField()),
                ('edited_at', models.DateTimeField(null=True, blank=True)),
                ('titulo', models.CharField(max_length=200)),
                ('contenido', models.TextField()),
                ('fecha_publicacion', models.DateTimeField(null=True, blank=True)),
                ('esta_publicado', models.BooleanField()),
                ('esta_vetado', models.BooleanField()),
                ('destacado', models.BooleanField()),
                ('imagen', models.CharField(max_length=100, null=True, blank=True)),
                ('imagen_menu', models.CharField(max_length=100, null=True, blank=True)),
                ('imagen_menu_seleccionada', models.CharField(max_length=100, null=True, blank=True)),
                ('ee', models.BooleanField()),
            ],
            options={
                'db_table': 'blog_post',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='BlogPostTags',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
            ],
            options={
                'db_table': 'blog_post_tags',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='BlogTag',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('nombre', models.CharField(max_length=50)),
            ],
            options={
                'db_table': 'blog_tag',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='BlogTipoblog',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('nombre', models.CharField(max_length=50)),
            ],
            options={
                'db_table': 'blog_tipoblog',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='CeleryPeriodictaskmeta',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('name', models.CharField(unique=True, max_length=255)),
                ('last_run_at', models.DateTimeField()),
                ('total_run_count', models.IntegerField()),
            ],
            options={
                'db_table': 'celery_periodictaskmeta',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='CeleryTaskmeta',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('task_id', models.CharField(unique=True, max_length=255)),
                ('status', models.CharField(max_length=50)),
                ('result', models.TextField(null=True, blank=True)),
                ('date_done', models.DateTimeField()),
                ('traceback', models.TextField(null=True, blank=True)),
            ],
            options={
                'db_table': 'celery_taskmeta',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='CeleryTasksetmeta',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('taskset_id', models.CharField(unique=True, max_length=255)),
                ('result', models.TextField()),
                ('date_done', models.DateTimeField()),
            ],
            options={
                'db_table': 'celery_tasksetmeta',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='CongresoActividadpersona',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('created_at', models.DateTimeField()),
                ('edited_at', models.DateTimeField(null=True, blank=True)),
                ('fecha_hora', models.DateTimeField()),
                ('texto', models.TextField()),
                ('object_id', models.IntegerField()),
                ('periodo_id', models.IntegerField(null=True, blank=True)),
            ],
            options={
                'db_table': 'congreso_actividadpersona',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='CongresoAlianza',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('created_at', models.DateTimeField()),
                ('edited_at', models.DateTimeField(null=True, blank=True)),
                ('periodo_id', models.IntegerField(null=True, blank=True)),
            ],
            options={
                'db_table': 'congreso_alianza',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='CongresoAlianzapartido',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('created_at', models.DateTimeField()),
                ('edited_at', models.DateTimeField(null=True, blank=True)),
                ('tiempo', models.BooleanField()),
            ],
            options={
                'db_table': 'congreso_alianzapartido',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='CongresoAval',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('nombre', models.CharField(max_length=150)),
            ],
            options={
                'db_table': 'congreso_aval',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='CongresoBancada',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('created_at', models.DateTimeField()),
                ('edited_at', models.DateTimeField(null=True, blank=True)),
                ('nombre', models.CharField(max_length=50)),
                ('posicion', models.CharField(max_length=50)),
            ],
            options={
                'db_table': 'congreso_bancada',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='CongresoCamara',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('nombre', models.CharField(max_length=100)),
            ],
            options={
                'db_table': 'congreso_camara',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='CongresoCampania',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('created_at', models.DateTimeField()),
                ('edited_at', models.DateTimeField(null=True, blank=True)),
                ('aspira', models.IntegerField()),
                ('sitio_web', models.CharField(max_length=200, null=True, blank=True)),
                ('correo', models.CharField(max_length=75, null=True, blank=True)),
                ('propuestas', models.TextField(null=True, blank=True)),
                ('costo_total', models.IntegerField(null=True, blank=True)),
                ('circunscripcion', models.IntegerField(null=True, blank=True)),
                ('tipo_voto', models.IntegerField(null=True, blank=True)),
                ('camara_id', models.IntegerField(null=True, blank=True)),
                ('periodo_id', models.IntegerField(null=True, blank=True)),
                ('inversion_dinero', models.CharField(max_length=40, null=True, blank=True)),
                ('financiacion_recursos_propios', models.CharField(max_length=20, null=True, blank=True)),
                ('financiacion_prestamos', models.CharField(max_length=20, null=True, blank=True)),
                ('financiacion_donaciones', models.CharField(max_length=20, null=True, blank=True)),
                ('financiacion_empresa_privada', models.CharField(max_length=20, null=True, blank=True)),
                ('fuente_financiacion_personas', models.CharField(max_length=20, null=True, blank=True)),
                ('numero_lista', models.CharField(max_length=150, null=True, blank=True)),
            ],
            options={
                'db_table': 'congreso_campania',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='CongresoCampaniaSectores',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
            ],
            options={
                'db_table': 'congreso_campania_sectores',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='CongresoCandidatosConcejo',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('nombre_completo', models.CharField(max_length=150)),
                ('nombres', models.CharField(max_length=100)),
                ('apellidos', models.CharField(max_length=100)),
                ('cedula', models.CharField(max_length=15, null=True, blank=True)),
                ('genero', models.CharField(max_length=1)),
                ('telefono_candidato', models.CharField(max_length=50, null=True, blank=True)),
                ('email_candidato', models.CharField(max_length=75, null=True, blank=True)),
                ('sitio_web', models.CharField(max_length=200, null=True, blank=True)),
                ('facebook_candidato', models.CharField(max_length=260, null=True, blank=True)),
                ('twitter_candidato', models.CharField(max_length=260, null=True, blank=True)),
                ('biografia', models.TextField(null=True, blank=True)),
                ('propuestas', models.TextField(null=True, blank=True)),
                ('tipo_voto', models.IntegerField(null=True, blank=True)),
                ('imagen_concejo', models.CharField(max_length=100, null=True, blank=True)),
                ('por_que_votar', models.TextField(null=True, blank=True)),
                ('numero_lista', models.IntegerField(null=True, blank=True)),
                ('actualmente_concejal', models.BooleanField()),
            ],
            options={
                'db_table': 'congreso_candidatos_concejo',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='CongresoCargo',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('created_at', models.DateTimeField()),
                ('edited_at', models.DateTimeField(null=True, blank=True)),
                ('cargo', models.CharField(max_length=140, null=True, blank=True)),
                ('entidad', models.CharField(max_length=140, null=True, blank=True)),
                ('fecha_inicio', models.DateField(null=True, blank=True)),
                ('fecha_final', models.DateField(null=True, blank=True)),
            ],
            options={
                'db_table': 'congreso_cargo',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='CongresoCargocamara',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('nombre', models.CharField(max_length=50)),
            ],
            options={
                'db_table': 'congreso_cargocamara',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='CongresoCargocomision',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('nombre', models.CharField(max_length=50)),
            ],
            options={
                'db_table': 'congreso_cargocomision',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='CongresoCargopolitico',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('created_at', models.DateTimeField()),
                ('edited_at', models.DateTimeField(null=True, blank=True)),
                ('cargo', models.CharField(max_length=140)),
                ('fecha_inicio', models.DateField()),
                ('fecha_final', models.DateField()),
                ('resultado', models.CharField(max_length=1)),
            ],
            options={
                'db_table': 'congreso_cargopolitico',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='CongresoCircunscripcion',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('nombre', models.CharField(max_length=140)),
            ],
            options={
                'db_table': 'congreso_circunscripcion',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='CongresoComision',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('created_at', models.DateTimeField()),
                ('edited_at', models.DateTimeField(null=True, blank=True)),
                ('nombre', models.CharField(max_length=50)),
                ('permanente', models.BooleanField()),
                ('descripcion', models.TextField(null=True, blank=True)),
                ('imagen', models.CharField(max_length=100, null=True, blank=True)),
                ('orden', models.IntegerField(null=True, blank=True)),
                ('correo', models.CharField(max_length=75, null=True, blank=True)),
                ('oficina', models.CharField(max_length=100, null=True, blank=True)),
                ('telefono', models.CharField(max_length=50, null=True, blank=True)),
                ('url', models.CharField(max_length=200, null=True, blank=True)),
            ],
            options={
                'db_table': 'congreso_comision',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='CongresoCongresistadebancada',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('created_at', models.DateTimeField()),
                ('edited_at', models.DateTimeField(null=True, blank=True)),
                ('fecha_inicio', models.DateField(null=True, blank=True)),
                ('fecha_fin', models.DateField(null=True, blank=True)),
            ],
            options={
                'db_table': 'congreso_congresistadebancada',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='CongresoCongresistadepartido',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('created_at', models.DateTimeField()),
                ('edited_at', models.DateTimeField(null=True, blank=True)),
                ('fecha_inicio', models.DateField(null=True, blank=True)),
                ('fecha_fin', models.DateField(null=True, blank=True)),
            ],
            options={
                'db_table': 'congreso_congresistadepartido',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='CongresoContadorcongresistas',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('congresistas', models.IntegerField()),
                ('candidatos', models.IntegerField()),
                ('object_id', models.IntegerField()),
            ],
            options={
                'db_table': 'congreso_contadorcongresistas',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='CongresoEntidad',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('created_at', models.DateTimeField()),
                ('edited_at', models.DateTimeField(null=True, blank=True)),
                ('nombre', models.CharField(unique=True, max_length=200)),
            ],
            options={
                'db_table': 'congreso_entidad',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='CongresoEstadopartido',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('created_at', models.DateTimeField()),
                ('edited_at', models.DateTimeField(null=True, blank=True)),
                ('nombre', models.CharField(max_length=150)),
                ('es_activo', models.BooleanField()),
            ],
            options={
                'db_table': 'congreso_estadopartido',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='CongresoFinanciador',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('nombre', models.CharField(max_length=150)),
                ('telefono', models.CharField(max_length=50)),
                ('direccion', models.CharField(max_length=150)),
                ('porcentaje', models.IntegerField()),
            ],
            options={
                'db_table': 'congreso_financiador',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='CongresoIntegrantecamara',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('created_at', models.DateTimeField()),
                ('edited_at', models.DateTimeField(null=True, blank=True)),
                ('fecha_inicio', models.DateField(null=True, blank=True)),
                ('fecha_final', models.DateField(null=True, blank=True)),
            ],
            options={
                'db_table': 'congreso_integrantecamara',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='CongresoIntegrantecomision',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('created_at', models.DateTimeField()),
                ('edited_at', models.DateTimeField(null=True, blank=True)),
                ('fecha_inicio', models.DateField(null=True, blank=True)),
                ('fecha_final', models.DateField(null=True, blank=True)),
                ('periodo_id', models.IntegerField(null=True, blank=True)),
            ],
            options={
                'db_table': 'congreso_integrantecomision',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='CongresoLink',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('link', models.CharField(max_length=300, null=True, blank=True)),
            ],
            options={
                'db_table': 'congreso_link',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='CongresoPartido',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('created_at', models.DateTimeField()),
                ('edited_at', models.DateTimeField(null=True, blank=True)),
                ('nombre', models.CharField(max_length=100)),
                ('fecha_fundacion', models.DateField(null=True, blank=True)),
                ('lugar_creacion', models.CharField(max_length=100, null=True, blank=True)),
                ('direccion_sede_principal', models.CharField(max_length=100, null=True, blank=True)),
                ('sitio_web', models.CharField(max_length=200, null=True, blank=True)),
                ('twitter', models.CharField(max_length=30, null=True, blank=True)),
                ('telefono', models.CharField(max_length=50, null=True, blank=True)),
                ('estatutos', models.CharField(max_length=200, null=True, blank=True)),
                ('lineamientos', models.TextField(null=True, blank=True)),
                ('resenia_historica', models.TextField(null=True, blank=True)),
                ('propuestas', models.TextField(null=True, blank=True)),
                ('fundador', models.CharField(max_length=140, null=True, blank=True)),
                ('posicion_ideologica', models.IntegerField(null=True, blank=True)),
                ('sistema_avales', models.IntegerField(null=True, blank=True)),
                ('logo', models.CharField(max_length=100, null=True, blank=True)),
                ('rango_edad_id', models.IntegerField(null=True, blank=True)),
                ('telefono_contacto', models.CharField(max_length=150, null=True, blank=True)),
                ('celular_contacto', models.CharField(max_length=150, null=True, blank=True)),
                ('correo_contacto', models.CharField(max_length=75, null=True, blank=True)),
                ('direccion_contacto', models.CharField(max_length=150, null=True, blank=True)),
                ('estado_id', models.IntegerField(null=True, blank=True)),
                ('nombre_contacto', models.CharField(max_length=150, null=True, blank=True)),
                ('old_id', models.IntegerField(null=True, blank=True)),
                ('feed_rss', models.CharField(max_length=200, null=True, blank=True)),
                ('datos_clave', models.TextField(null=True, blank=True)),
                ('es_bancada', models.BooleanField()),
            ],
            options={
                'db_table': 'congreso_partido',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='CongresoPartidoAvales',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
            ],
            options={
                'db_table': 'congreso_partido_avales',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='CongresoPartidoSectores',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
            ],
            options={
                'db_table': 'congreso_partido_sectores',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='CongresoPeriodo',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('created_at', models.DateTimeField()),
                ('edited_at', models.DateTimeField(null=True, blank=True)),
                ('fecha_inicio', models.DateField()),
                ('fecha_fin', models.DateField()),
                ('old_id', models.IntegerField(null=True, blank=True)),
                ('activo', models.NullBooleanField()),
            ],
            options={
                'db_table': 'congreso_periodo',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='CongresoPeriodocongresista',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('created_at', models.DateTimeField()),
                ('edited_at', models.DateTimeField(null=True, blank=True)),
                ('fecha_inicio', models.DateField(null=True, blank=True)),
                ('fecha_fin', models.DateField(null=True, blank=True)),
                ('camara_id', models.IntegerField(null=True, blank=True)),
                ('depto_mayor_votacion_id', models.IntegerField(null=True, blank=True)),
                ('numero_lista', models.IntegerField(null=True, blank=True)),
                ('numero_votos', models.IntegerField(null=True, blank=True)),
                ('circunscripcion_id', models.IntegerField(null=True, blank=True)),
            ],
            options={
                'db_table': 'congreso_periodocongresista',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='CongresoPersona',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('created_at', models.DateTimeField()),
                ('edited_at', models.DateTimeField(null=True, blank=True)),
                ('facebook_id', models.CharField(max_length=100, null=True, blank=True)),
                ('activation_key', models.CharField(max_length=40)),
                ('nombres', models.CharField(max_length=50)),
                ('apellidos', models.CharField(max_length=50)),
                ('sitio_web', models.CharField(max_length=200, null=True, blank=True)),
                ('telefono', models.CharField(max_length=50, null=True, blank=True)),
                ('cedula', models.CharField(max_length=15, null=True, blank=True)),
                ('imagen', models.CharField(max_length=100, null=True, blank=True)),
                ('anio_nacimiento', models.DateField(null=True, blank=True)),
                ('nivel_educativo', models.CharField(max_length=50, null=True, blank=True)),
                ('fecha_fallecimiento', models.DateField(null=True, blank=True)),
                ('flickr_user', models.CharField(max_length=260, null=True, blank=True)),
                ('youtube_user', models.CharField(max_length=260, null=True, blank=True)),
                ('tumblr_user', models.CharField(max_length=260, null=True, blank=True)),
                ('twitter_user', models.CharField(max_length=260, null=True, blank=True)),
                ('linkedin_user', models.CharField(max_length=260, null=True, blank=True)),
                ('blogspot_user', models.CharField(max_length=260, null=True, blank=True)),
                ('posicion_ideologica', models.IntegerField(null=True, blank=True)),
                ('facebook_user', models.CharField(max_length=260, null=True, blank=True)),
                ('mini_bio', models.TextField(null=True, blank=True)),
                ('estrato', models.CharField(max_length=2, null=True, blank=True)),
                ('idrac', models.CharField(max_length=15, null=True, blank=True)),
                ('estado_civil', models.CharField(max_length=20, null=True, blank=True)),
                ('religion', models.CharField(max_length=30, null=True, blank=True)),
                ('frecuencia_actos_religiosos', models.CharField(max_length=20, null=True, blank=True)),
            ],
            options={
                'db_table': 'congreso_persona',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='CongresoPosicion',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('created_at', models.DateTimeField()),
                ('edited_at', models.DateTimeField(null=True, blank=True)),
                ('a_favor', models.IntegerField()),
                ('comentario', models.TextField(null=True, blank=True)),
            ],
            options={
                'db_table': 'congreso_posicion',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='CongresoPosicionpartido',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('created_at', models.DateTimeField()),
                ('edited_at', models.DateTimeField(null=True, blank=True)),
                ('a_favor', models.IntegerField()),
            ],
            options={
                'db_table': 'congreso_posicionpartido',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='CongresoProblema',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('created_at', models.DateTimeField()),
                ('edited_at', models.DateTimeField(null=True, blank=True)),
                ('descripcion', models.TextField()),
            ],
            options={
                'db_table': 'congreso_problema',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='CongresoProblemaLink',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
            ],
            options={
                'db_table': 'congreso_problema_link',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='CongresoProposicion',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('created_at', models.DateTimeField()),
                ('edited_at', models.DateTimeField(null=True, blank=True)),
                ('nombre', models.CharField(max_length=200)),
            ],
            options={
                'db_table': 'congreso_proposicion',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='CongresoReemplazo',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('created_at', models.DateTimeField()),
                ('edited_at', models.DateTimeField(null=True, blank=True)),
                ('periodo_inicial', models.DateField()),
                ('periodo_final', models.DateField()),
            ],
            options={
                'db_table': 'congreso_reemplazo',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='CongresoTemaopinion',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('created_at', models.DateTimeField()),
                ('edited_at', models.DateTimeField(null=True, blank=True)),
                ('nombre', models.CharField(max_length=100)),
                ('descripcion', models.TextField(null=True, blank=True)),
                ('activo', models.BooleanField()),
                ('obtenido_votacion', models.BooleanField()),
            ],
            options={
                'db_table': 'congreso_temaopinion',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='CongresoTipoactividad',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('nombre', models.CharField(unique=True, max_length=100)),
            ],
            options={
                'db_table': 'congreso_tipoactividad',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='CongresoTipocomision',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('nombre', models.CharField(max_length=60)),
            ],
            options={
                'db_table': 'congreso_tipocomision',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='CongresoTipoperiodo',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('nombre', models.CharField(max_length=60)),
            ],
            options={
                'db_table': 'congreso_tipoperiodo',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='CongresoTipoproblema',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('nombre', models.CharField(max_length=200)),
            ],
            options={
                'db_table': 'congreso_tipoproblema',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='CongresoTrayectoria',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('trayectoria_anio', models.IntegerField()),
                ('cargo', models.CharField(max_length=100, null=True, blank=True)),
                ('partido', models.CharField(max_length=100, null=True, blank=True)),
                ('votos', models.CharField(max_length=100, null=True, blank=True)),
                ('es_electo', models.IntegerField(null=True, blank=True)),
            ],
            options={
                'db_table': 'congreso_trayectoria',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='CorteSentencia',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('anio', models.CharField(max_length=4)),
                ('cod_sentencia', models.CharField(max_length=20)),
                ('num_sentencia', models.CharField(max_length=20)),
                ('id_norma', models.TextField()),
                ('titulo_norma', models.TextField()),
                ('mas_normas', models.BooleanField()),
                ('otras_normas', models.TextField()),
                ('numero_camara', models.CharField(max_length=100)),
                ('numero_senado', models.CharField(max_length=100)),
                ('oficio', models.BooleanField()),
                ('fecha_norma', models.DateField()),
            ],
            options={
                'db_table': 'corte_sentencia',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='CorteTipocaso',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('descripcion', models.CharField(max_length=150)),
            ],
            options={
                'db_table': 'corte_tipocaso',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='CorteTipodemanda',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('descripcion', models.CharField(max_length=150)),
            ],
            options={
                'db_table': 'corte_tipodemanda',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='DbsettingsSetting',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('module_name', models.CharField(max_length=255)),
                ('class_name', models.CharField(max_length=255)),
                ('attribute_name', models.CharField(max_length=255)),
                ('value', models.CharField(max_length=255)),
            ],
            options={
                'db_table': 'dbsettings_setting',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='DjangoAdminLog',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('action_time', models.DateTimeField()),
                ('object_id', models.TextField(null=True, blank=True)),
                ('object_repr', models.CharField(max_length=200)),
                ('action_flag', models.SmallIntegerField()),
                ('change_message', models.TextField()),
            ],
            options={
                'db_table': 'django_admin_log',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='DjangoCommentFlags',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('flag', models.CharField(max_length=30)),
                ('flag_date', models.DateTimeField()),
            ],
            options={
                'db_table': 'django_comment_flags',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='DjangoComments',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('object_pk', models.TextField()),
                ('user_name', models.CharField(max_length=50)),
                ('user_email', models.CharField(max_length=75)),
                ('user_url', models.CharField(max_length=200)),
                ('comment', models.TextField()),
                ('submit_date', models.DateTimeField()),
                ('ip_address', models.GenericIPAddressField(null=True, blank=True)),
                ('is_public', models.BooleanField()),
                ('is_removed', models.BooleanField()),
            ],
            options={
                'db_table': 'django_comments',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='DjangoContentType',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('name', models.CharField(max_length=100)),
                ('app_label', models.CharField(max_length=100)),
                ('model', models.CharField(max_length=100)),
            ],
            options={
                'db_table': 'django_content_type',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='DjangoEvolution',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('app_label', models.CharField(max_length=200)),
                ('label', models.CharField(max_length=100)),
            ],
            options={
                'db_table': 'django_evolution',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='DjangoFlatpage',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('url', models.CharField(max_length=100)),
                ('title', models.CharField(max_length=200)),
                ('content', models.TextField()),
                ('enable_comments', models.BooleanField()),
                ('template_name', models.CharField(max_length=70)),
                ('registration_required', models.BooleanField()),
            ],
            options={
                'db_table': 'django_flatpage',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='DjangoFlatpageSites',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
            ],
            options={
                'db_table': 'django_flatpage_sites',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='DjangoMigrations',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('app', models.CharField(max_length=255)),
                ('name', models.CharField(max_length=255)),
                ('applied', models.DateTimeField()),
            ],
            options={
                'db_table': 'django_migrations',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='DjangoProjectVersion',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('signature', models.TextField()),
                ('when', models.DateTimeField()),
            ],
            options={
                'db_table': 'django_project_version',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='DjangoSelect2Keymap',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('key', models.CharField(unique=True, max_length=40)),
                ('value', models.CharField(max_length=100)),
                ('accessed_on', models.DateTimeField()),
            ],
            options={
                'db_table': 'django_select2_keymap',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='DjangoSession',
            fields=[
                ('session_key', models.CharField(max_length=40, serialize=False, primary_key=True)),
                ('session_data', models.TextField()),
                ('expire_date', models.DateTimeField()),
            ],
            options={
                'db_table': 'django_session',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='DjangoSite',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('domain', models.CharField(max_length=100)),
                ('name', models.CharField(max_length=50)),
            ],
            options={
                'db_table': 'django_site',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='FacebookconnectFacebookprofile',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('facebook_id', models.BigIntegerField(unique=True)),
            ],
            options={
                'db_table': 'facebookconnect_facebookprofile',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='FacebookconnectFacebooktemplate',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('name', models.CharField(unique=True, max_length=50)),
                ('template_bundle_id', models.BigIntegerField()),
            ],
            options={
                'db_table': 'facebookconnect_facebooktemplate',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='GeneralDepartamento',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('nombre', models.CharField(max_length=70)),
                ('old_id', models.IntegerField(null=True, blank=True)),
            ],
            options={
                'db_table': 'general_departamento',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='GeneralGenero',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('nombre', models.CharField(max_length=10)),
            ],
            options={
                'db_table': 'general_genero',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='GeneralMunicipio',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('nombre', models.CharField(max_length=70)),
            ],
            options={
                'db_table': 'general_municipio',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='GeneralProfesion',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('nombre', models.CharField(max_length=100)),
            ],
            options={
                'db_table': 'general_profesion',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='GeneralRangoedad',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('edad_minima', models.SmallIntegerField()),
                ('edad_maxima', models.SmallIntegerField()),
            ],
            options={
                'db_table': 'general_rangoedad',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='GeneralRegion',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('nombre', models.CharField(max_length=70)),
            ],
            options={
                'db_table': 'general_region',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='GeneralSectorindustria',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('nombre', models.CharField(max_length=140)),
            ],
            options={
                'db_table': 'general_sectorindustria',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='GeneralTema',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('created_at', models.DateTimeField()),
                ('edited_at', models.DateTimeField(null=True, blank=True)),
                ('nombre', models.CharField(max_length=100)),
                ('descripcion', models.TextField(null=True, blank=True)),
                ('activo', models.BooleanField()),
            ],
            options={
                'db_table': 'general_tema',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='GrappelliHelp',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('title', models.CharField(max_length=50)),
                ('order', models.IntegerField()),
            ],
            options={
                'db_table': 'grappelli_help',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='GrappelliHelpitem',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('title', models.CharField(max_length=200)),
                ('link', models.CharField(max_length=200)),
                ('body', models.TextField()),
                ('order', models.IntegerField()),
            ],
            options={
                'db_table': 'grappelli_helpitem',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='GrappelliNavigation',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('title', models.CharField(max_length=30)),
                ('order', models.IntegerField()),
            ],
            options={
                'db_table': 'grappelli_navigation',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='GrappelliNavigationitem',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('title', models.CharField(max_length=30)),
                ('link', models.CharField(max_length=200)),
                ('category', models.CharField(max_length=1)),
                ('order', models.IntegerField()),
            ],
            options={
                'db_table': 'grappelli_navigationitem',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='GrupoGrupo',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('created_at', models.DateTimeField()),
                ('edited_at', models.DateTimeField(null=True, blank=True)),
                ('nombre_grupo', models.CharField(max_length=200)),
                ('nombre_contacto', models.CharField(max_length=120, null=True, blank=True)),
                ('email_contacto', models.CharField(max_length=120, null=True, blank=True)),
                ('sitio_web', models.CharField(max_length=200, null=True, blank=True)),
                ('fecha_fundacion', models.DateField(null=True, blank=True)),
                ('objetivos', models.TextField(null=True, blank=True)),
                ('activo', models.BooleanField()),
                ('imagen', models.CharField(max_length=100, null=True, blank=True)),
                ('direccion', models.CharField(max_length=100, null=True, blank=True)),
                ('mision', models.TextField(null=True, blank=True)),
                ('vision', models.TextField(null=True, blank=True)),
                ('telefono', models.CharField(max_length=20, null=True, blank=True)),
                ('twitter', models.CharField(max_length=100, null=True, blank=True)),
                ('descripcion', models.TextField(null=True, blank=True)),
                ('facebook', models.CharField(max_length=100, null=True, blank=True)),
            ],
            options={
                'db_table': 'grupo_grupo',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='HomeBanner',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('titulo', models.CharField(max_length=140)),
                ('texto', models.CharField(max_length=280)),
                ('img', models.CharField(max_length=100)),
                ('activo', models.BooleanField()),
                ('orden', models.IntegerField()),
                ('link', models.CharField(max_length=200, null=True, blank=True)),
            ],
            options={
                'db_table': 'home_banner',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='HomeFeedhome',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('nombre', models.CharField(unique=True, max_length=100)),
                ('feed_rss', models.CharField(max_length=200)),
                ('enlace', models.CharField(max_length=200, null=True, blank=True)),
                ('logo', models.CharField(max_length=100)),
                ('activo', models.BooleanField()),
            ],
            options={
                'db_table': 'home_feedhome',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='HomeFrasemencion',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('frase', models.TextField()),
                ('sitio', models.CharField(max_length=70)),
                ('enlace', models.CharField(max_length=200, null=True, blank=True)),
            ],
            options={
                'db_table': 'home_frasemencion',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='HomeLinkfooter',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('nombre', models.CharField(max_length=80)),
                ('enlace', models.CharField(max_length=200)),
                ('activo', models.BooleanField()),
                ('orden', models.IntegerField()),
            ],
            options={
                'db_table': 'home_linkfooter',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='HomeSeccionhome',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('nombre', models.CharField(max_length=40)),
                ('nombre_template', models.CharField(max_length=200)),
                ('activo', models.BooleanField()),
                ('orden', models.IntegerField()),
            ],
            options={
                'db_table': 'home_seccionhome',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='OpenidConsumerAssociation',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('server_url', models.TextField()),
                ('handle', models.CharField(max_length=255)),
                ('secret', models.TextField()),
                ('issued', models.IntegerField()),
                ('lifetime', models.IntegerField()),
                ('assoc_type', models.TextField()),
            ],
            options={
                'db_table': 'openid_consumer_association',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='OpenidConsumerNonce',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('server_url', models.CharField(max_length=200)),
                ('timestamp', models.IntegerField()),
                ('salt', models.CharField(max_length=50)),
            ],
            options={
                'db_table': 'openid_consumer_nonce',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='OrdenDelDiaCargocitado',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('created_at', models.DateTimeField()),
                ('edited_at', models.DateTimeField(null=True, blank=True)),
                ('nombre', models.CharField(max_length=200)),
                ('old_id', models.IntegerField(null=True, blank=True)),
            ],
            options={
                'db_table': 'orden_del_dia_cargocitado',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='OrdenDelDiaCitacionCitantes',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
            ],
            options={
                'db_table': 'orden_del_dia_citacion_citantes',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='OrdenDelDiaCitacionOtrosInvitados',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
            ],
            options={
                'db_table': 'orden_del_dia_citacion_otros_invitados',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='OrdenDelDiaCitado',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('created_at', models.DateTimeField()),
                ('edited_at', models.DateTimeField(null=True, blank=True)),
                ('nombres', models.CharField(max_length=200, null=True, blank=True)),
                ('old_id', models.IntegerField(null=True, blank=True)),
                ('imagen', models.CharField(max_length=100, null=True, blank=True)),
            ],
            options={
                'db_table': 'orden_del_dia_citado',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='OrdenDelDiaCitadoasistentecitacion',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('asiste', models.NullBooleanField()),
                ('delega_asistencia', models.BooleanField()),
                ('excuso', models.BooleanField()),
            ],
            options={
                'db_table': 'orden_del_dia_citadoasistentecitacion',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='OrdenDelDiaEntidadcitado',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('created_at', models.DateTimeField()),
                ('edited_at', models.DateTimeField(null=True, blank=True)),
                ('nombre', models.CharField(max_length=200)),
                ('old_id', models.IntegerField(null=True, blank=True)),
            ],
            options={
                'db_table': 'orden_del_dia_entidadcitado',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='OrdenDelDiaInvitadoasistentecitacion',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('asiste', models.NullBooleanField()),
                ('delega_asistencia', models.BooleanField()),
                ('excuso', models.BooleanField()),
            ],
            options={
                'db_table': 'orden_del_dia_invitadoasistentecitacion',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='OrdenDelDiaItemdeordendeldia',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('orden', models.IntegerField()),
                ('proposito', models.TextField(null=True, blank=True)),
                ('importante', models.BooleanField()),
                ('realizado', models.NullBooleanField()),
                ('menu_realizado', models.CharField(max_length=2, null=True, blank=True)),
            ],
            options={
                'db_table': 'orden_del_dia_itemdeordendeldia',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='OrdenDelDiaOrdendeldia',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('fecha_programada', models.DateTimeField()),
                ('fecha_realizada', models.DateField(null=True, blank=True)),
                ('comentarios', models.TextField(null=True, blank=True)),
                ('realizado', models.CharField(max_length=2, null=True, blank=True)),
            ],
            options={
                'db_table': 'orden_del_dia_ordendeldia',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='OrdenDelDiaOrdendeldiaCamaras',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
            ],
            options={
                'db_table': 'orden_del_dia_ordendeldia_camaras',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='OrdenDelDiaOrdendeldiaComisiones',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
            ],
            options={
                'db_table': 'orden_del_dia_ordendeldia_comisiones',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='OrdenDelDiaTipocitacion',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('nombre', models.CharField(max_length=50)),
            ],
            options={
                'db_table': 'orden_del_dia_tipocitacion',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='OrdenDelDiaTipocitante',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('nombre', models.CharField(max_length=50)),
            ],
            options={
                'db_table': 'orden_del_dia_tipocitante',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='ProyectoDeLeyAutorproyectoley',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('created_at', models.DateTimeField()),
                ('edited_at', models.DateTimeField(null=True, blank=True)),
                ('autor_id', models.IntegerField()),
            ],
            options={
                'db_table': 'proyecto_de_ley_autorproyectoley',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='ProyectoDeLeyClasevotacion',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('nombre', models.CharField(max_length=50)),
                ('descripcion', models.TextField(null=True, blank=True)),
            ],
            options={
                'db_table': 'proyecto_de_ley_clasevotacion',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='ProyectoDeLeyEstadodeproyectodeley',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('fecha', models.DateField(null=True, blank=True)),
                ('gaceta', models.CharField(max_length=50, null=True, blank=True)),
                ('old_id', models.IntegerField(null=True, blank=True)),
                ('nota', models.TextField(null=True, blank=True)),
                ('camara_id', models.IntegerField(null=True, blank=True)),
                ('numero_titulos', models.IntegerField(null=True, blank=True)),
                ('numero_articulos', models.IntegerField(null=True, blank=True)),
                ('observaciones', models.TextField(null=True, blank=True)),
                ('orden', models.IntegerField(null=True, blank=True)),
            ],
            options={
                'db_table': 'proyecto_de_ley_estadodeproyectodeley',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='ProyectoDeLeyEstadodeproyectodeleyComisiones',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
            ],
            options={
                'db_table': 'proyecto_de_ley_estadodeproyectodeley_comisiones',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='ProyectoDeLeyEstadodeproyectodeleyPonentes',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
            ],
            options={
                'db_table': 'proyecto_de_ley_estadodeproyectodeley_ponentes',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='ProyectoDeLeyEstadoproyectoley',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('nombre', models.CharField(max_length=50)),
                ('old_id', models.IntegerField(null=True, blank=True)),
            ],
            options={
                'db_table': 'proyecto_de_ley_estadoproyectoley',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='ProyectoDeLeyIniciativa',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('nombre', models.CharField(max_length=50)),
            ],
            options={
                'db_table': 'proyecto_de_ley_iniciativa',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='ProyectoDeLeyLegislatura',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('nombre', models.CharField(max_length=7)),
                ('fecha_inicio', models.DateField()),
                ('fecha_fin', models.DateField()),
            ],
            options={
                'db_table': 'proyecto_de_ley_legislatura',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='ProyectoDeLeyOtroautor',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('created_at', models.DateTimeField()),
                ('edited_at', models.DateTimeField(null=True, blank=True)),
                ('nombre', models.CharField(unique=True, max_length=200)),
                ('imagen', models.CharField(max_length=100, null=True, blank=True)),
            ],
            options={
                'db_table': 'proyecto_de_ley_otroautor',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='ProyectoDeLeyProyectoley',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('created_at', models.DateTimeField()),
                ('edited_at', models.DateTimeField(null=True, blank=True)),
                ('titulo', models.TextField()),
                ('sinapsis', models.TextField(null=True, blank=True)),
                ('numero_camara', models.CharField(max_length=10, null=True, blank=True)),
                ('numero_senado', models.CharField(max_length=10, null=True, blank=True)),
                ('fecha_radicacion', models.DateField(null=True, blank=True)),
                ('tags', models.CharField(max_length=200, null=True, blank=True)),
                ('old_id', models.IntegerField(null=True, blank=True)),
                ('camara_id', models.IntegerField(null=True, blank=True)),
                ('legislatura_id', models.IntegerField(null=True, blank=True)),
                ('enlace_a_texto', models.CharField(max_length=200, null=True, blank=True)),
                ('enlace_a_informe_derecho_justo', models.CharField(max_length=200, null=True, blank=True)),
                ('alias', models.CharField(max_length=300, null=True, blank=True)),
                ('importancia', models.FloatField()),
                ('destacado', models.BooleanField()),
                ('alcance', models.IntegerField(null=True, blank=True)),
                ('norma', models.CharField(max_length=300, null=True, blank=True)),
            ],
            options={
                'db_table': 'proyecto_de_ley_proyectoley',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='ProyectoDeLeyTextosComparacion',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('orden', models.SmallIntegerField()),
                ('diferencias_encoded', models.TextField()),
            ],
            options={
                'db_table': 'proyecto_de_ley_textos_comparacion',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='ProyectoDeLeyTextosTextoproyectoley',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('created_at', models.DateTimeField()),
                ('edited_at', models.DateTimeField(null=True, blank=True)),
                ('texto_html', models.TextField(null=True, blank=True)),
                ('texto_plano', models.TextField(null=True, blank=True)),
            ],
            options={
                'db_table': 'proyecto_de_ley_textos_textoproyectoley',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='ProyectoDeLeyTipoproyecto',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('nombre', models.CharField(max_length=50)),
            ],
            options={
                'db_table': 'proyecto_de_ley_tipoproyecto',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='ProyectoDeLeyTipovotacion',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('nombre', models.CharField(max_length=50)),
                ('procedimental', models.BooleanField()),
                ('descripcion', models.TextField(null=True, blank=True)),
            ],
            options={
                'db_table': 'proyecto_de_ley_tipovotacion',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='ProyectoDeLeyVotacion',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('created_at', models.DateTimeField()),
                ('edited_at', models.DateTimeField(null=True, blank=True)),
                ('fecha', models.DateField()),
                ('motivo', models.TextField()),
                ('a_favor', models.CharField(max_length=50, null=True, blank=True)),
                ('en_contra', models.CharField(max_length=50, null=True, blank=True)),
                ('votosfavor', models.IntegerField(db_column='votosFavor')),
                ('votoscontra', models.IntegerField(db_column='votosContra')),
                ('aprobado', models.NullBooleanField()),
                ('gaceta', models.CharField(max_length=50, null=True, blank=True)),
                ('acta', models.CharField(max_length=50, null=True, blank=True)),
                ('observaciones', models.TextField(null=True, blank=True)),
                ('votacion_en_dia', models.IntegerField(null=True, blank=True)),
                ('destacada', models.BooleanField()),
                ('old_id', models.CharField(max_length=100, null=True, blank=True)),
                ('aprobada', models.IntegerField(null=True, blank=True)),
                ('cuatrienio_id', models.IntegerField(null=True, blank=True)),
                ('votosabstencion', models.IntegerField(null=True, db_column='votosAbstencion', blank=True)),
                ('numero_no_asistencias', models.IntegerField()),
                ('numero_asistencias', models.IntegerField()),
                ('datos_importacion', models.TextField(null=True, blank=True)),
                ('resultados_importacion', models.TextField(null=True, blank=True)),
            ],
            options={
                'db_table': 'proyecto_de_ley_votacion',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='ProyectoDeLeyVotacionCamaras',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
            ],
            options={
                'db_table': 'proyecto_de_ley_votacion_camaras',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='ProyectoDeLeyVotacionComisiones',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
            ],
            options={
                'db_table': 'proyecto_de_ley_votacion_comisiones',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='ProyectoDeLeyVotacionEstadosProyecto',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
            ],
            options={
                'db_table': 'proyecto_de_ley_votacion_estados_proyecto',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='ProyectoDeLeyVotacionpartido',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('created_at', models.DateTimeField()),
                ('edited_at', models.DateTimeField(null=True, blank=True)),
                ('numero_votos_si', models.IntegerField()),
                ('numero_votos_no', models.IntegerField()),
                ('numero_votos_abstencion', models.IntegerField()),
                ('opcion_preferida', models.IntegerField(null=True, blank=True)),
            ],
            options={
                'db_table': 'proyecto_de_ley_votacionpartido',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='ProyectoDeLeyVoto',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('created_at', models.DateTimeField()),
                ('edited_at', models.DateTimeField(null=True, blank=True)),
                ('voto', models.IntegerField()),
            ],
            options={
                'db_table': 'proyecto_de_ley_voto',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='ProyectoDeLeyVotociudadano',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('voto', models.BooleanField()),
            ],
            options={
                'db_table': 'proyecto_de_ley_votociudadano',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='ReportesReporte',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('nombre', models.CharField(max_length=140)),
                ('descripcion', models.TextField()),
                ('enlace', models.CharField(max_length=200)),
                ('activo', models.BooleanField()),
                ('orden', models.IntegerField()),
            ],
            options={
                'db_table': 'reportes_reporte',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='SouthMigrationhistory',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('app_name', models.CharField(max_length=255)),
                ('migration', models.CharField(max_length=255)),
                ('applied', models.DateTimeField()),
            ],
            options={
                'db_table': 'south_migrationhistory',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='CongresoCongresista',
            fields=[
                ('persona_ptr', models.OneToOneField(primary_key=True, serialize=False, to='Informes.CongresoPersona')),
                ('es_candidato', models.BooleanField()),
                ('orgullo', models.TextField(null=True, blank=True)),
                ('ha_reemplazado', models.BooleanField()),
                ('es_activo', models.BooleanField()),
                ('cantidad_actividades', models.IntegerField()),
                ('cantidad_comentarios', models.IntegerField()),
                ('comision_actual_id', models.IntegerField(null=True, blank=True)),
                ('periodo_actual_id', models.IntegerField(null=True, blank=True)),
                ('es_congresista', models.NullBooleanField()),
                ('ha_sido_congresista', models.NullBooleanField()),
                ('numero_votos_partido', models.IntegerField(null=True, blank=True)),
                ('vota_con_partido', models.FloatField(null=True, blank=True)),
                ('old_id', models.IntegerField(null=True, blank=True)),
                ('investigado', models.CharField(max_length=150, null=True, blank=True)),
                ('slug', models.CharField(max_length=250, null=True, blank=True)),
                ('biografia', models.TextField(null=True, blank=True)),
                ('campania_actual_id', models.IntegerField(null=True, blank=True)),
                ('actividad_actual_id', models.IntegerField(null=True, blank=True)),
                ('numero_oficina', models.CharField(max_length=100, null=True, blank=True)),
                ('telefono_oficina', models.CharField(max_length=100, null=True, blank=True)),
                ('ha_sido_reemplazo', models.NullBooleanField()),
                ('tiene_formula_electoral_aspirante_a_la_otra_camara', models.NullBooleanField()),
                ('formula_electoral', models.CharField(max_length=50, null=True, blank=True)),
                ('ha_estado_en_bancada_diferente', models.NullBooleanField()),
                ('ha_ejercido_cargo_diferente', models.NullBooleanField()),
                ('cargo_popular', models.CharField(max_length=20, null=True, blank=True)),
                ('ha_ejercido_cargo_en_rama_ejecutiva', models.NullBooleanField()),
                ('ha_sido_dirigente_sindical', models.NullBooleanField()),
                ('ha_sido_dirigente_gremial', models.NullBooleanField()),
                ('tiene_pariente_en_la_politica', models.NullBooleanField()),
                ('es_representante_camara', models.NullBooleanField()),
                ('es_candidato_camara', models.NullBooleanField()),
                ('es_senador', models.NullBooleanField()),
                ('es_candidato_senador', models.NullBooleanField()),
                ('cargo_ejecutivo', models.CharField(max_length=20, null=True, blank=True)),
                ('pariente_politica', models.CharField(max_length=40, null=True, blank=True)),
                ('ha_tenido_pariente_en_la_politica', models.NullBooleanField()),
                ('pariente_politica_inactivo', models.CharField(max_length=40, null=True, blank=True)),
            ],
            options={
                'db_table': 'congreso_congresista',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='CongresoPosicionproposicion',
            fields=[
                ('posicion_ptr', models.OneToOneField(primary_key=True, serialize=False, to='Informes.CongresoPosicion')),
            ],
            options={
                'db_table': 'congreso_posicionproposicion',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='CongresoPosiciontemaopinion',
            fields=[
                ('posicion_ptr', models.OneToOneField(primary_key=True, serialize=False, to='Informes.CongresoPosicion')),
            ],
            options={
                'db_table': 'congreso_posiciontemaopinion',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='CongresoSecretario',
            fields=[
                ('persona_ptr', models.OneToOneField(primary_key=True, serialize=False, to='Informes.CongresoPersona')),
                ('fecha_inicio', models.DateField()),
                ('fecha_final', models.DateField()),
            ],
            options={
                'db_table': 'congreso_secretario',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='OrdenDelDiaCitacion',
            fields=[
                ('itemdeordendeldia_ptr', models.OneToOneField(primary_key=True, serialize=False, to='Informes.OrdenDelDiaItemdeordendeldia')),
                ('plenaria', models.BooleanField()),
                ('tags', models.CharField(max_length=200, null=True, blank=True)),
                ('fecha_proposicion', models.DateField(null=True, blank=True)),
                ('old_id', models.IntegerField(null=True, blank=True)),
                ('detalles', models.TextField(null=True, blank=True)),
                ('gacetas', models.CharField(max_length=50, null=True, blank=True)),
                ('cuestionario', models.TextField(null=True, blank=True)),
                ('numero_proposicion', models.CharField(max_length=200, null=True, blank=True)),
                ('respuesta', models.TextField(null=True, blank=True)),
                ('duplicado', models.BooleanField()),
            ],
            options={
                'db_table': 'orden_del_dia_citacion',
                'managed': False,
            },
        ),
        migrations.CreateModel(
            name='OrdenDelDiaProyectoenordendia',
            fields=[
                ('itemdeordendeldia_ptr', models.OneToOneField(primary_key=True, serialize=False, to='Informes.OrdenDelDiaItemdeordendeldia')),
            ],
            options={
                'db_table': 'orden_del_dia_proyectoenordendia',
                'managed': False,
            },
        ),
    ]
