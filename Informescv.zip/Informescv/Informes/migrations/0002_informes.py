# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations
import ckeditor.fields


class Migration(migrations.Migration):

    dependencies = [
        ('Informes', '0001_initial'),
    ]

    operations = [
        migrations.CreateModel(
            name='Informes',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('titulo', models.CharField(max_length=100, verbose_name='T\xedtulo del Informe')),
                ('contenido', ckeditor.fields.RichTextField(verbose_name='Contenido del Informe')),
                ('fecha_publicacion', models.DateTimeField(verbose_name='Fecha de publicaci\xf3n')),
                ('usuarios_premium', models.BooleanField(default=True)),
                ('usuarios_general', models.BooleanField(default=False)),
            ],
        ),
    ]
