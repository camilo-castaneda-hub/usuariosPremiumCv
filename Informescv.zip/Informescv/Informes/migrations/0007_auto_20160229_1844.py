# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('Informes', '0006_auto_20160229_1834'),
    ]

    operations = [
        migrations.AlterField(
            model_name='informemensual',
            name='comentarios',
            field=models.CharField(max_length=300, null=True, verbose_name='Comentarios del informe'),
        ),
        migrations.AlterField(
            model_name='informemensual',
            name='url',
            field=models.URLField(null=True),
        ),
        migrations.AlterField(
            model_name='informenoticias',
            name='comentarios',
            field=models.CharField(max_length=300, null=True, verbose_name='Comentarios del informe'),
        ),
        migrations.AlterField(
            model_name='informesemanal',
            name='comentarios',
            field=models.CharField(max_length=300, null=True, verbose_name='Comentarios del informe'),
        ),
        migrations.AlterField(
            model_name='informesemanal',
            name='url',
            field=models.URLField(null=True),
        ),
    ]
