# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('Informes', '0012_equipo_imgperfil'),
    ]

    operations = [
        migrations.AlterField(
            model_name='equipo',
            name='ImgPerfil',
            field=models.ImageField(default='http://www.allard.ubc.ca/sites/www.allard.ubc.ca/files/default_images/profileIcon_1.png', upload_to='images/profileCv'),
        ),
    ]
