from __future__ import unicode_literals
from django.shortcuts import render
from django.contrib.auth.views import login
#from .models import (ProyectoDeLeyProyectoley, BlogPost, BlogTipoblog, BlogBlog)
from .models import (InformeNoticias, InformeSemanal, InformeMensual, Equipo)
from django.contrib.auth.decorators import login_required
from datetime import datetime



def informes(request):
    if (request.user.is_authenticated()):
        vars = {}
        hoy = datetime.today()
        info_noticias = InformeNoticias.objects.all().order_by('fecha_publicacion')[1:]
        vars['in_no'] = info_noticias
        vars['today'] = hoy
        return render(request, 'Informes/informes.html', vars)
    return login(request, template_name='base.html')


def boletines(request):
    if (request.user.is_authenticated()):
        vars = {}
        hoy = datetime.today()
        vars['today'] = hoy
        return render(request, 'Informes/boletines.html', vars)
    return login(request, template_name='base.html')

def noticias(request):
    if (request.user.is_authenticated()):
        vars = {}
        hoy = datetime.today()
        vars['today'] = hoy
        info_mensual = InformeMensual.objects.all().order_by('fecha_publicacion')[1:]
        vars['in_me'] = info_mensual
        return render(request, 'Informes/noticias.html', vars)
    return login(request, template_name='base.html')

def libro(request):
    if (request.user.is_authenticated()):
        vars = {}
        info_semanal = InformeSemanal.objects.all().order_by('fecha_publicacion')[1:]
        vars['in_se'] = info_semanal
        return render(request, 'Informes/boletines_libro.html', vars)
    return login(request, template_name='base.html')

def home(request):
    if (request.user.is_authenticated()):
    #-------------llamo bd cuando esta auth----------------#
    	#project = ProyectoDeLeyProyectoley.objects.all()
        #return render(request, 'Informes/home.html', {'project': project})
        hoy = datetime.today()
        vars = {}
        vars['today'] = hoy
        # incluir instrucciones
        return render(request, 'Informes/home.html', vars)
    return login(request, template_name='Informes/home.html')

#def projects(request):
	#project = ProyectoDeLeyProyectoley.objects.all()
	#return render(request, 'Informes/projects.html', {'project': project})

def equipo(request):

        vars = {}
        hoy = datetime.today()
        integrante = Equipo.objects.all()
        vars['equipo'] = integrante
        vars['today'] = hoy
        return render(request, 'equipo.html', vars)


@login_required
def profile(request):
    return render(request, template_name='Informes/profile.html')