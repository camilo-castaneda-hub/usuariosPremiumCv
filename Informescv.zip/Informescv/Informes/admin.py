from django.contrib import admin
from .models import (InformeNoticias, InformeSemanal, InformeMensual, Equipo)

# Register your models here.

class InformesNoticiasAdmin(admin.ModelAdmin):
    fieldsets = (
        (None, {
            'fields': ('titulo', 'contenido', 'fecha_publicacion','usuarios_premium', 'usuarios_general' ,'comentarios')
        }),
    )
    list_display = ('titulo', 'fecha_publicacion')
    list_filter = ('titulo', 'fecha_publicacion')
    ordering = ('fecha_publicacion', 'fecha_publicacion')
    search_fields = ('titulo','fecha_publicacion')


class InformeSemanalAdmin(admin.ModelAdmin):
    fieldsets = (
        (None, {
            'fields': ('titulo', 'contenido', 'fecha_publicacion','usuarios_premium', 'usuarios_general' )
        }),
        ('Opciones avanzadas', {
            'classes': ('collapse',),
            'fields': ('comentarios', 'url'),
        }),
    )
    list_display = ('titulo', 'fecha_publicacion')
    list_filter = ('titulo', 'fecha_publicacion')
    ordering = ('fecha_publicacion', 'fecha_publicacion')
    search_fields = ('titulo','fecha_publicacion')

class InformeMensualAdmin(admin.ModelAdmin):
    fieldsets = (
        (None, {
            'fields': ('titulo', 'contenido', 'fecha_publicacion','usuarios_premium', 'usuarios_general' )
        }),
        ('Opciones avanzadas', {
            'classes': ('collapse',),
            'fields': ('comentarios', 'url'),
        }),
    )
    list_display = ('titulo', 'fecha_publicacion')
    list_filter = ('titulo', 'fecha_publicacion')
    ordering = ('fecha_publicacion', 'fecha_publicacion')
    search_fields = ('titulo','fecha_publicacion')

class EquipoAdmin(admin.ModelAdmin):
    fieldsets = (
        (None, {
            'fields': ('Nombre', 'Cargo', 'Contenido', 'Correo', 'ImgPerfil')
        }),
        ('Opciones avanzadas', {
            'classes': ('collapse',),
            'fields': ('facebook', 'twitter', 'plusgoogle'),
        }),
        )
    list_display = ('Nombre', 'Cargo')
    list_filter = ('Nombre', 'Cargo')
    search_fields = ('Nombre', 'Cargo', 'Correo')

admin.site.register(InformeNoticias, InformesNoticiasAdmin)
admin.site.register(InformeSemanal, InformeSemanalAdmin)
admin.site.register(InformeMensual, InformeMensualAdmin)
admin.site.register(Equipo, EquipoAdmin)
